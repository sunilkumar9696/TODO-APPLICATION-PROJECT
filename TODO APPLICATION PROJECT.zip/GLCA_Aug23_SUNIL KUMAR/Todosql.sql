create database todoapp;

select*from todos;