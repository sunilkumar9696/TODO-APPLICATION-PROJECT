package com.gl.todo.service;

import java.util.List;

import com.gl.todo.dto.TodoDto;

public interface TodoService {

	TodoDto createTodo(TodoDto todoDto);
	TodoDto updateTodo(int id ,TodoDto todoDto);
	TodoDto getTodoById(int id);
	List<TodoDto>getAllTodos();
	void deleteTodo(int id);
	TodoDto completeTodo(int id);
	TodoDto inCompleteTodo(int id);
}
