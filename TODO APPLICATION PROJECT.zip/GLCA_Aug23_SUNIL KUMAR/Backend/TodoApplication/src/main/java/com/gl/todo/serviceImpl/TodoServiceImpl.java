package com.gl.todo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gl.todo.dto.TodoDto;
import com.gl.todo.entity.ToDo;
import com.gl.todo.exception.ResourceNotFound;
import com.gl.todo.mapper.TodoMapper;
import com.gl.todo.repository.TodoRepo;
import com.gl.todo.service.TodoService;

@Service
public class TodoServiceImpl implements TodoService {

	@Autowired
	private TodoRepo todoRepo;
	
	@Override
	public TodoDto createTodo(TodoDto todoDto) {
		ToDo todo = TodoMapper.mapToTodo(todoDto);
		ToDo saveTodo = todoRepo.save(todo);
		
		return TodoMapper.mapToTodoDto(saveTodo);
	}

	@Override
	public TodoDto updateTodo(int id, TodoDto todoDto) {
		ToDo todo = todoRepo.findById(id)
				.orElseThrow(()->new ResourceNotFound("Record with " + id+" not found" ));
		
		todo.setCompleted(todoDto.isCompleted());
		todo.setTitle(todoDto.getTitle());
		todo.setDescription(todoDto.getDescription());
		
		ToDo save = todoRepo.save(todo);
		return TodoMapper.mapToTodoDto(save);
	}

	@Override
	public TodoDto getTodoById(int id) {
		ToDo todo = todoRepo.findById(id).orElseThrow(
				()->new ResourceNotFound("Record with " + id+" not found" ));
		return TodoMapper.mapToTodoDto(todo);
	}

	@Override
	public List<TodoDto> getAllTodos() {
		List<ToDo> todos = todoRepo.findAll();
		
		return todos.stream().map((todo)->TodoMapper.mapToTodoDto(todo)).toList();
	}

	@Override
	public void deleteTodo(int id) {
		ToDo todo = todoRepo.findById(id).orElseThrow(
				()->new ResourceNotFound("Record with " + id+" not found" ));
		todoRepo.deleteById(id);
	}

	@Override
	public TodoDto completeTodo(int id) {
		ToDo todo = todoRepo.findById(id).orElseThrow(
				()->new ResourceNotFound("Record with " + id+" not found" ));
		todo.setCompleted(true);
		ToDo save = todoRepo.save(todo);
		return TodoMapper.mapToTodoDto(save);
	}

	@Override
	public TodoDto inCompleteTodo(int id) {
		ToDo todo = todoRepo.findById(id).orElseThrow(
				()->new ResourceNotFound("Record with " + id+" not found" ));
		todo.setCompleted(false);
		ToDo save = todoRepo.save(todo);
		return TodoMapper.mapToTodoDto(save);
	}

}
