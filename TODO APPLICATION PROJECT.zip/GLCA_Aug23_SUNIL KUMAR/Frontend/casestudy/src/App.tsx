import { BrowserRouter, Route, Switch } from "react-router-dom";
import ListOfTodos from "./ListOfTodos";
import TodoComponent from "./TodoComponent";
import './Style.css';

const App = ()=>{
    return(<>
    <BrowserRouter>
    <Switch>
    <Route exact path="/" component={ListOfTodos}></Route>
    <Route path="/update-todo/:id" component={TodoComponent}></Route>
    <Route path="/add-todo" component={TodoComponent}></Route>
    </Switch>
    </BrowserRouter>
    </>)
}

export default App;