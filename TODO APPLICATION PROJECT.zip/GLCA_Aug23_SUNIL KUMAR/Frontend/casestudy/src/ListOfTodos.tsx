import { useEffect, useState } from "react";
import { completeTodo, deleteTodo, inCompleteTodo, ListTodos } from "./service/Todo";
import { Button, Container, Table } from "react-bootstrap";
import { Link, useHistory } from "react-router-dom";
import './Style.css';

type Todo = {
    id: number,
    title: string,
    description: string,
    completed: boolean
}

const ListOfTodos = () => {
    let [todos, setTodos] = useState<Todo[]>([]);

    function getTodos() {
        ListTodos().then((response) => {
            console.log(response.data);
            setTodos(response.data);
        }).catch((error) => console.log(error));
    }

    useEffect(() => {
        getTodos();
    }, []);

    let navigator = useHistory();

    function editTodo(id: number) {
        navigator.push(`update-todo/${id}`);
    }

    function completeTask(id: number) {
        completeTodo(id).then((response) => {
            console.log(response.data);
            getTodos();
        }).catch((error) => console.log(error));
    }

    function inCompleteTask(id: number) {
        inCompleteTodo(id).then((response) => {
            console.log(response.data);
            getTodos();
        }).catch((error) => console.log(error));
    }

    function remove(id: number) {
        deleteTodo(id).then((response) => {
            console.log(response.data);
            getTodos();
        }).catch((error) => console.log(error));
    }

    return (
        <>
            <header>Todo Management Application</header>
            <h2 style={{ textAlign: "center" }}>List Of Todos</h2>

            <Container>
                <Table striped bordered hover>
                    <thead>
                        <Link to="/add-todo" className="btn btn-success">Add Todo</Link>
                        <tr>
                            <th>Todo Title</th>
                            <th>Todo Description</th>
                            <th>Todo Completed</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {todos.map((todo)=>
                            <tr key={todo.id}>
                                <td>{todo.title}</td>
                                <td>{todo.description}</td>
                                <td>{todo.completed ? "YES" : "NO"}</td>
                                <td>
                                    <Button type="button" variant="primary" onClick={() => editTodo(todo.id)}>Update</Button>
                                    <Button type="button" variant="warning" onClick={() => remove(todo.id)}>Delete</Button>
                                    <Button type="button" variant="info" onClick={() => completeTask(todo.id)}>Complete</Button>
                                    <Button type="button" variant="danger" onClick={() => inCompleteTask(todo.id)}>InComplete</Button>
                                </td>
                            </tr>)}
                    </tbody>
                </Table>
            </Container>

            <footer style={{ textAlign: "center" }}>&copy; Copyright Reserved</footer>
        </>
    )
}

export default ListOfTodos;
