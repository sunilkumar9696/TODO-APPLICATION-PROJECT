import { FormEvent, useEffect, useState } from "react";
import { Button, Container, Form } from "react-bootstrap";
import { useHistory, useParams } from "react-router-dom";
import { createTodo, getTodo, updateTodo } from "./service/Todo";

interface RouteParam {
    id: string
}

type Todo = {
    id: number,
    title: string,
    description: string,
    completed: boolean
}

const TodoComponent = () => {
    let [title, setTitle] = useState<string>("");
    let [description, setDescription] = useState<string>("");
    let [completed, setCompleted] = useState<string>("");
    const [errors, setErrors] = useState({
        title:'',
        description:'',
        completed:''
    })

    function validateForm() {
        let valid = true;
        const errorsCopy = { ...errors }
        console.log(errorsCopy)
        if (title.trim()) {
            errorsCopy.title ='';
        } else {
            errorsCopy.title = 'TODO Title is required';
            valid = false;
        }
          if(description.trim()){
              errorsCopy.description ='';
          } else {
              errorsCopy.description = 'TODO Description is required';
              valid = false;
          }

        setErrors(errorsCopy)
        return valid;
    }

    const { id } = useParams<RouteParam>();

    function changeHeader() {
        if (id) {
            return (<>
                <h1 style={{ textAlign: "center" }}>Update TODO</h1>
            </>)
        } else {
            return (<>
                <h1 style={{ textAlign: "center" }}>Add TODO</h1>
            </>)
        }
    }

    function getTodoById(id: number) {
        getTodo(id).then((response: any) => {
            console.log(response.data);
            setTitle(response.data.title);
            setDescription(response.data.description);
            setCompleted(response.data.completed);
        }).catch((error) => console.log(error));
    }

    useEffect(() => { getTodoById(Number(id)) }, [id])

    let navigator = useHistory();

    function saveTodo(e: FormEvent) {
        e.preventDefault();
        if (!validateForm()) {
            return;
        }
        let todo = { title, description, completed }

        if (id) {
            updateTodo(Number(id), todo).then((response) => {
                console.log(response.data);
                navigator.push("/")
            }).catch((error) => console.log(error))
        } else {
            createTodo(todo).then((response) => {
                console.log(response.data);
                navigator.push("/")
            }).catch((error) => console.log(error));
        }
    }

    return (<>
    <header>Todo Management Application</header>
        <Container style={{ marginTop: "50px" }}>
            {changeHeader()}
            <Form>
                <Form.Group className="mb-3" controlId="title">
                    <Form.Label>Todo Title</Form.Label>
                    <Form.Control type="text" placeholder="Enter Todo Title"
                        value={title}
                        className={`form-control ${ errors.title ? 'is-invalid':'' }`}
                        onChange={(e) => setTitle(e.target.value)} />
                    {errors.title && <div className='invalid-feedback'> {errors.title} </div>}
                </Form.Group>


                <Form.Group className="mb-3" controlId="description">
                    <Form.Label>Todo Description</Form.Label>
                    <Form.Control type="text" placeholder="Enter Todo Description"
                        value={description}
                        className={`form-control ${ errors.description ? 'is-invalid':'' }`}
                        onChange={(e) => setDescription(e.target.value)} />
                        {errors.description && <div className='invalid-feedback'> {errors.description} </div>}
                </Form.Group>

                <Form.Group className="mb-3" controlId="completed">
                    <Form.Label>Todo Completed</Form.Label>
                    <Form.Select
                        className="mb-3"
                        value={completed}
                        onChange={(e) => setCompleted(e.target.value)}
                    >
                        <option value="false">No</option>
                        <option value="true">Yes</option>
                    </Form.Select>

                </Form.Group>

                <Button variant="primary" type="submit" onClick={(e) => saveTodo(e)}>
                    Submit
                </Button>
            </Form>
        </Container>
        <footer style={{ textAlign: "center" }}>&copy; Copyright Reserved</footer>
    </>)
}

export default TodoComponent;