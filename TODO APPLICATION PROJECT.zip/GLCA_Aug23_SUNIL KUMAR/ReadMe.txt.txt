1. import backend in the eclipse

2. After importing create schema (todoapp)before running the project.

3. Then open the frontend in visual studio code

4. And install the casestudy

5. Run the backend program and then followed by run the front end too